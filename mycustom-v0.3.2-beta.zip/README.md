<p align="center"><img src="mycustom-logo.png" width="420" alt="MyCustom"></p>

<h1 align="center">MyCustom</h1>
<p align="center"><b>Animated text, personal emojis and custom fonts for Discord.</b><br>
A BetterDiscord plugin that turns your message into a transparent animated image that looks just like a normal message.</p>

> **Beta (v0.3.2).** Formerly called Customizant. Things may break, especially after Discord updates. Please report bugs!

## What it does

Type a message with effects and press Enter. MyCustom renders it with your Discord theme colors, font and size, and puts it in your upload tray as a transparent animated WebP. Press Enter again to send. People see a message that waves, shakes, glows or scrolls. Only **you** need the plugin.

Messages without effects are sent normally.

## Install

1. Install [BetterDiscord](https://betterdiscord.app).
2. Download **MyCustom.plugin.js**.
3. In Discord: **User Settings → BetterDiscord → Plugins → Open Plugins Folder**, and drop the file in.
4. Switch **MyCustom** on.

### Upgrading from Customizant

Delete the old **Customizant.plugin.js** from your plugins folder before adding **MyCustom.plugin.js**, or both will run at once. Your settings, emojis and fonts carry over automatically.

## How to use it

Wrap text in an effect, with the text always last:

```
(wave/hello)
(#ff0000/hello)
(#ff0000/wave/hello)        ← stack as many as you like
(wave/hi (shake/there))     ← nesting works too
```

Any bracket works: `()` `[]` `{}` `<>`. Prefer menus? Select text, **right-click the message box → MyCustom**.

### Effects

| Code | Effect |
|---|---|
| `(rb/text)` or `:two words:` | Rainbow |
| `(wave/text)` | Letters ripple up and down |
| `(shake/text)` | Letters jitter |
| `(bounce/text)` | Letters hop one by one |
| `(glow/text)` | Pulsing glow |
| `(pulse/text)` | Fades in and out |
| `(glitch/text)` | RGB glitches |
| `(spin/text)` | Each letter spins, one after another |
| `(jelly/text)` | Squish and stretch |
| `(drunk/text)` | Letters sway and stumble |
| `(scramble/text)` | Hacker-style decode |
| `(ghost/text)` | Floats with faded echoes |
| `(swing/text)` | Eased swinging |
| `(bop/text)` or `(bop=120/text)` | Headbop: squashes on every beat (default 75 BPM) |
| `(bill/text)` `(bilr/text)` `(bilu/text)` `(bild/text)` | Billboard on just that part: a little scrolling window. Stack: `(bill/bilu/text)` |

### Colors

| Code | Result |
|---|---|
| `(#ff0000/text)` | Any hex color |
| `(#ff5e62>#ffd23f>#00c6ff/text)` | Flowing gradient, as many colors as you like |
| `(gradient(#f0f/#0ff)/text)` | Same, other spelling (the `/` after the bracket is optional) |

### Whole message

Put these anywhere in your message:

| Flag | Effect |
|---|---|
| `/nudge` | MSN-style nudge: shakes hard, then stays still |
| `/shake` | Everything shakes |
| `/rb` `/wave` `/swing` `/bop` | Rainbow / wave / swing / headbop everything |
| `/spin` `/jelly` `/drunk` `/scramble` `/ghost` | The odd ones, for everything |
| `/type` | Typewriter |
| `/billboard` or `/bill` `/bilr` `/bilu` `/bild` | Scrolling sign: left, right, up, down. Stack them: `/bill /bilu` = diagonal, `/bill /bilr` = back and forth |
| `/cz` | Turn the message into an image even with no effects |

### Personal emojis

Add your own pictures under **plugin settings ⚙️ → My emojis**, then type `.name.` in any message, in any server or DM. Animated GIFs and WebPs keep moving. They're your own images, so they travel with you everywhere.

### Fonts

Add fonts under **plugin settings ⚙️ → My fonts**. The first one becomes `fonta`, then `fontb` … `fontz`, `fontaa`, `fontab` and so on.

```
(fonta/hello)
(fontb/#ff0000/wave/hello)
```

### Discord formatting still works

`**bold**`, `*italic*`, `__underline__`, `~~strike~~`, `` `code` ``, code blocks, `# headings`, `-# subtext`, `> quotes`, lists. Normal and server emojis render as real emoji images. Put a backslash before a symbol to keep it as plain text: `\(wave/text)`.

## Good to know

- When someone replies to your message, Discord's reply preview shows "Click to see attachment" instead of the text.
- On screens with Windows display scaling above 100% (or Discord zoomed in), the text can look slightly softer than normal text. If it looks small, lower **Max width** in the plugin settings so it fits the chat.
- The text color is baked into the image. It matches **your** theme, so it looks best for people using the same theme.
- Client mods like BetterDiscord are against Discord's Terms of Service. Use at your own risk.
- If BetterDiscord breaks after a Discord update, close Discord fully and run the BetterDiscord installer with **Repair**.

## Reporting bugs

Open an issue with a screenshot and, if possible, the red error lines from the console (**Ctrl+Shift+I → Console**) that start with `[MyCustom]`.

## License

MIT. See [LICENSE](LICENSE).
