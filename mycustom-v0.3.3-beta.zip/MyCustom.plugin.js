/**
 * @name MyCustom
 * @description Animated text, personal emojis and custom fonts for your messages. Turns your message into a transparent animated image that looks like a normal message. Write (wave/text), (#ff0000/text), /nudge and more, then press Enter.
 * @version 0.3.3-beta
 * @author SevconFactsYoutube
 */

/* How it works
 * 1. You press Enter on a message that uses a MyCustom effect.
 * 2. The plugin stops that text from being sent, renders it to an animated WebP
 *    using your current Discord theme colors, font and font size,
 *    and puts the image in the upload tray.
 * 3. Press Enter again to send the image.
 * Messages without effects are sent normally.
 *
 * Effects
 *   [rainbow]..[/rainbow]  or  :text with spaces:    rainbow
 *   [wave]..[/wave]  [shake]..[/shake]  [bounce]..[/bounce]
 *   [glow]..[/glow]  [pulse]..[/pulse]  [glitch]..[/glitch]
 *   [color=#ff00aa]..[/color]
 *   Short form: (wave/text) (rb/text) (#ff0000/text)
 *   Fonts: add them in the plugin settings, then (fonta/text), (fontb/text) … (fontz), (fontaa), (fontab) …
 *   (headbop/text) or (bop=120/text): squash on every beat, BPM optional (default 75)
 *   (swing/text): eased swinging   (#ff0000>#00ff00>#0000ff/text) or (gradient(#f00/#0f0)/text): flowing gradient, any number of colors
 *   Stack them, text always last: (#ff0000/wave/text)  — can be nested: (wave/hi (shake/there))
 *   Or right-click the message box → MyCustom to pick effects and colors from a menu.
 *   Any bracket works: [wave] (wave) {wave} <wave>, and they can be mixed: (wave)hi[/wave]
 *   /shake /rb /wave /type /swing /bop   anywhere in the message = whole message (/shk still works)
 *   /billboard or /bill /bilr /bilu /bild   scrolling sign: left, right, up, down. Stack them:
 *        /bill /bilu = diagonal, /bill /bilr = slides back and forth, /bilu /bild = bobs up and down
 *   Billboard on part of a message: (bill/text) (bilr/text) (bilu/text) (bild/text) — stack: (bill/bilu/text)
 *   /nudge                 MSN-style nudge: shakes hard for half a second, then stays still
 *   Odd ones: (spin/text) (jelly/text) (drunk/text) (scramble/text) (ghost/text)
 *   /cz                    force conversion even with no effects
 * My emojis: add pictures in the plugin settings, then type .name. anywhere (no Nitro needed).
 * Emojis: normal emojis are drawn as Discord's Twemoji images; server emojis (also animated) work too.
 * Discord markdown still works: # ## ### -# > - 1. ** * __ ~~ ` ```
 */

const NS = "MyCustom";
// Settings, emojis and fonts saved by the old "Customizant" name carry over automatically
function loadData(key) {
  let v = BdApi.Data.load(NS, key);
  if (v == null) { v = BdApi.Data.load("Customizant", key); if (v != null) BdApi.Data.save(NS, key, v); }
  return v;
}

module.exports = class MyCustom {
  constructor(meta) { this.meta = meta; }

  start() {
    this.settings = Object.assign({ loopSeconds: 1.4, maxWidth: 550 }, loadData("settings") || {});
    PERSONAL = loadData("emojis") || {};
    FONTS = loadData("fonts") || {};
    for (const code of Object.keys(FONTS)) registerFont(code);
    const MessageActions = BdApi.Webpack.getByKeys("sendMessage", "editMessage");
    if (!MessageActions) { BdApi.UI.showToast("MyCustom: couldn't find Discord's message sender. Discord may have updated.", { type: "error" }); return; }
    BdApi.Patcher.instead(NS, MessageActions, "sendMessage", (that, args, original) => {
      const [channelId, message] = args;
      const content = message && message.content;
      if (!content || !this.wantsConversion(content)) return original.apply(that, args);
      this.convertAndUpload(channelId, content).catch(err => {
        console.error("[MyCustom]", err);
        BdApi.UI.showToast("MyCustom failed, sending as normal text instead.", { type: "error" });
        original.apply(that, args);
      });
      return Promise.resolve();
    });
    this.patchMenu();
  }

  stop() {
    BdApi.Patcher.unpatchAll(NS);
    for (const code of Object.keys(FONT_FACES)) unregisterFont(code);
    if (this.unpatchMenu) { this.unpatchMenu(); this.unpatchMenu = null; }
  }

  /* ---------- right-click menu in the message box ---------- */
  patchMenu() {
    if (!BdApi.ContextMenu || !BdApi.ContextMenu.patch) return;
    const COLORS = [["Red", "#f23f43"], ["Orange", "#ff8c1a"], ["Yellow", "#f0c420"], ["Green", "#23a55a"], ["Teal", "#1abc9c"],
      ["Blue", "#3b82f6"], ["Purple", "#9b59b6"], ["Pink", "#ff6fb5"], ["White", "#ffffff"], ["Grey", "#949ba4"]];
    const FX = [["Rainbow", "rb"], ["Wave", "wave"], ["Shake", "shake"], ["Bounce", "bounce"], ["Glow", "glow"], ["Pulse", "pulse"], ["Glitch", "glitch"], ["Headbop", "bop"], ["Swing", "swing"], ["Spin", "spin"], ["Jelly", "jelly"], ["Drunk", "drunk"], ["Scramble", "scramble"], ["Ghost", "ghost"]];
    const GRADS = [["Sunset", "#ff5e62>#ff9966>#ffd23f"], ["Ocean", "#00c6ff>#0072ff>#7b2ff7"], ["Candy", "#ff6fb5>#a78bfa>#60a5fa"], ["Toxic", "#a8ff00>#00ffa3"], ["Fire", "#ff2d00>#ffb300"]];
    this.unpatchMenu = BdApi.ContextMenu.patch("textarea-context", tree => {
      const sel = window.getSelection();
      this.savedRange = sel && sel.rangeCount ? sel.getRangeAt(0).cloneRange() : null;
      const items = [
        { type: "submenu", id: "cz-fx", label: "Effects", items: FX.map(([l, k]) => ({ id: "cz-fx-" + k, label: l, action: () => this.wrapSelection(k) })) },
        ...(Object.keys(FONTS).length ? [{ type: "submenu", id: "cz-font", label: "Font", items: Object.keys(FONTS)
          .sort((a, b) => a.length - b.length || a.localeCompare(b))
          .map(c => ({ id: "cz-font-" + c, label: `${FONTS[c].name} (font${c})`, action: () => this.wrapSelection("font" + c) })) }] : []),
        { type: "submenu", id: "cz-color", label: "Color", items: [
          ...COLORS.map(([l, h]) => ({ id: "cz-c-" + h.slice(1), label: l, action: () => this.wrapSelection(h) })),
          { id: "cz-c-custom", label: "Custom color…", action: () => this.pickColor() },
        ] },
        { type: "submenu", id: "cz-grad", label: "Gradient", items: GRADS.map(([l, g]) => ({ id: "cz-g-" + l.toLowerCase(), label: l, action: () => this.wrapSelection(g) })) },
        { type: "submenu", id: "cz-all", label: "Whole message", items: [["Nudge", "/nudge"], ["Billboard ←", "/bill"], ["Billboard →", "/bilr"], ["Billboard ↑", "/bilu"], ["Billboard ↓", "/bild"], ["Shake all", "/shake"], ["Rainbow all", "/rb"], ["Wave all", "/wave"], ["Swing all", "/swing"], ["Headbop all", "/bop"], ["Typewriter", "/type"]]
          .map(([l, f]) => ({ id: "cz-all-" + f.slice(1), label: l, action: () => this.insertFlag(f) })) },
      ];
      const menu = BdApi.ContextMenu.buildItem({ type: "submenu", id: "mycustom", label: "MyCustom", items });
      const kids = tree && tree.props && tree.props.children;
      if (Array.isArray(kids)) kids.push(menu); else if (tree && tree.props) tree.props.children = [kids, menu];
    });
  }

  focusBox() {
    const box = document.querySelector('[role="textbox"][data-slate-editor="true"]');
    if (box) box.focus();
    if (this.savedRange) { const s = window.getSelection(); s.removeAllRanges(); s.addRange(this.savedRange); }
    return box;
  }

  wrapSelection(mod) {
    if (!this.focusBox()) return;
    const text = window.getSelection().toString() || "text";
    document.execCommand("insertText", false, "(" + mod + "/" + text + ")");
  }

  insertFlag(flag) {
    const box = this.focusBox(); if (!box) return;
    const s = window.getSelection(); s.collapse(s.focusNode, s.focusOffset);
    document.execCommand("insertText", false, " " + flag + " ");
  }

  pickColor() {
    const input = document.createElement("input");
    input.type = "color"; input.value = this.lastColor || "#ff6fb5";
    input.style.cssText = "position:fixed;left:-100px;top:0;opacity:0";
    document.body.appendChild(input);
    const done = () => { input.remove(); };
    input.addEventListener("change", () => { this.lastColor = input.value; this.wrapSelection(input.value); done(); }, { once: true });
    input.addEventListener("blur", () => setTimeout(done, 500), { once: true });
    input.click();
  }

  getSettingsPanel() {
    const wrap = document.createElement("div");
    wrap.style.cssText = "display:flex;flex-direction:column;gap:12px;color:var(--text-normal,var(--text-default,#dbdee1))";
    const row = (label, key, min, max, step, unit) => {
      const r = document.createElement("label");
      r.style.cssText = "display:flex;gap:10px;align-items:center";
      const t = document.createElement("span"); t.textContent = label; t.style.minWidth = "120px";
      const i = document.createElement("input"); Object.assign(i, { type: "range", min, max, step, value: this.settings[key] });
      const v = document.createElement("span"); v.textContent = this.settings[key] + unit;
      i.oninput = () => { this.settings[key] = +i.value; v.textContent = i.value + unit; BdApi.Data.save(NS, "settings", this.settings); };
      r.append(t, i, v); return r;
    };
    wrap.append(row("Loop length", "loopSeconds", 0.6, 4, 0.2, " s"), row("Max width", "maxWidth", 200, 550, 10, " px"));
    wrap.append(this.fontPanel());
    wrap.append(this.emojiPanel());
    // Keep typing inside these fields. Without this, Discord and BetterDiscord grab the keys
    // (for example the plugin search box behind this window). Escape still closes the window.
    const keep = e => { if (e.key !== "Escape" && e.target.matches("input, textarea")) e.stopPropagation(); };
    for (const ev of ["keydown", "keypress", "keyup"]) wrap.addEventListener(ev, keep);
    return wrap;
  }

  /* ---------- font library (fonta, fontb … fontz, fontaa …) ---------- */
  fontPanel() {
    const box = document.createElement("div");
    box.style.cssText = "display:flex;flex-direction:column;gap:10px;border-top:1px solid var(--background-modifier-accent,#4e5058);padding-top:12px";
    const h = document.createElement("div"); h.textContent = "My fonts — type (fonta/text) in any message";
    h.style.cssText = "font-weight:600;font-size:14px";
    const list = document.createElement("div"); list.style.cssText = "display:flex;flex-direction:column;gap:6px;max-height:260px;overflow:auto";
    const save = () => BdApi.Data.save(NS, "fonts", FONTS);
    const render = () => {
      list.replaceChildren();
      const codes = Object.keys(FONTS).sort((a, b) => a.length - b.length || a.localeCompare(b));
      if (!codes.length) { const e = document.createElement("div"); e.textContent = "No fonts yet. Add one below — the first one becomes fonta."; e.style.opacity = ".7"; list.append(e); }
      for (const c of codes) {
        const r = document.createElement("div"); r.style.cssText = "display:flex;align-items:center;gap:12px";
        const code = document.createElement("code"); code.textContent = "font" + c; code.style.minWidth = "64px";
        const prev = document.createElement("span"); prev.textContent = FONTS[c].name + " — Hello 123";
        prev.style.cssText = `font-family:"${fontFamilyName(c)}",sans-serif;font-size:17px;flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap`;
        const del = document.createElement("button"); del.textContent = "Delete";
        del.style.cssText = "padding:4px 10px;border-radius:4px;border:0;background:var(--button-danger-background,#da373c);color:#fff;cursor:pointer";
        del.onclick = () => { unregisterFont(c); delete FONTS[c]; save(); render(); };
        r.append(code, prev, del); list.append(r);
      }
    };
    const add = document.createElement("div"); add.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;align-items:center";
    const file = document.createElement("input"); file.type = "file"; file.accept = ".ttf,.otf,.woff,.woff2";
    const btn = document.createElement("button"); btn.textContent = "Add font";
    btn.style.cssText = "padding:6px 12px;border-radius:4px;border:0;background:var(--brand-500,#5865f2);color:#fff;cursor:pointer";
    const msg = document.createElement("div"); msg.style.cssText = "font-size:13px;opacity:.85;width:100%";
    btn.onclick = () => {
      const fl = file.files[0];
      if (!fl) { msg.textContent = "Choose a .ttf, .otf, .woff or .woff2 file first."; return; }
      if (fl.size > 8 * 1024 * 1024) { msg.textContent = "That font is over 8 MB. Try a smaller file or a .woff2 version."; return; }
      const fr = new FileReader();
      fr.onload = async () => {
        const c = nextFontCode();
        FONTS[c] = { name: fl.name.replace(/\.[^.]+$/, ""), data: fr.result };
        try { await registerFont(c); }
        catch { delete FONTS[c]; msg.textContent = "That file couldn't be read as a font."; return; }
        save(); render(); file.value = "";
        msg.textContent = `Added as font${c} — use (font${c}/your text).`;
      };
      fr.readAsDataURL(fl);
    };
    add.append(file, btn, msg);
    render();
    box.append(h, list, add);
    return box;
  }

  /* ---------- personal emoji library (.name.) ---------- */
  emojiPanel() {
    const box = document.createElement("div");
    box.style.cssText = "display:flex;flex-direction:column;gap:10px;border-top:1px solid var(--background-modifier-accent,#4e5058);padding-top:12px";
    const h = document.createElement("div"); h.textContent = "My emojis — type .name. in any message";
    h.style.cssText = "font-weight:600;font-size:14px";
    const list = document.createElement("div"); list.style.cssText = "display:flex;flex-direction:column;gap:6px;max-height:260px;overflow:auto";
    const save = () => BdApi.Data.save(NS, "emojis", PERSONAL);
    const render = () => {
      list.replaceChildren();
      const names = Object.keys(PERSONAL).sort();
      if (!names.length) { const e = document.createElement("div"); e.textContent = "No emojis yet. Add one below."; e.style.opacity = ".7"; list.append(e); }
      for (const n of names) {
        const r = document.createElement("div"); r.style.cssText = "display:flex;align-items:center;gap:10px";
        const img = document.createElement("img"); img.src = PERSONAL[n]; img.style.cssText = "width:32px;height:32px;object-fit:contain";
        const code = document.createElement("code"); code.textContent = "." + n + ".";
        const del = document.createElement("button"); del.textContent = "Delete";
        del.style.cssText = "margin-left:auto;padding:4px 10px;border-radius:4px;border:0;background:var(--button-danger-background,#da373c);color:#fff;cursor:pointer";
        del.onclick = () => { delete PERSONAL[n]; save(); render(); };
        r.append(img, code, del); list.append(r);
      }
    };
    const add = document.createElement("div"); add.style.cssText = "display:flex;flex-wrap:wrap;gap:8px;align-items:center";
    // The name comes from the file name (catjam.png → .catjam.), so there's nothing to type.
    // Typing in this window doesn't work reliably because Discord grabs the keys.
    const file = document.createElement("input"); file.type = "file"; file.accept = "image/png,image/gif,image/webp,image/jpeg"; file.multiple = true;
    const btn = document.createElement("button"); btn.textContent = "Add emoji";
    btn.style.cssText = "padding:6px 12px;border-radius:4px;border:0;background:var(--brand-500,#5865f2);color:#fff;cursor:pointer";
    const msg = document.createElement("div"); msg.style.cssText = "font-size:13px;opacity:.85;width:100%";
    msg.textContent = "The file name becomes the emoji name: catjam.png → .catjam. Rename the file first to pick a different name. You can add several at once.";
    const nameFrom = fn => {
      let n = fn.replace(/\.[^.]+$/, "").toLowerCase().replace(/[^a-z0-9_]+/g, "_").replace(/^_+|_+$/g, "").slice(0, 32);
      if (n.length < 2) n = (n + "emoji").slice(0, 32);
      let out = n, k = 2; while (out in PERSONAL) out = (n.slice(0, 30) + k++);
      return out;
    };
    const read = fl => new Promise((res, rej) => { const fr = new FileReader(); fr.onload = () => res(fr.result); fr.onerror = rej; fr.readAsDataURL(fl); });
    btn.onclick = async () => {
      const files = [...file.files];
      if (!files.length) { msg.textContent = "Choose an image file first."; return; }
      const added = [], skipped = [];
      for (const fl of files) {
        if (fl.size > 2 * 1024 * 1024) { skipped.push(fl.name); continue; }
        const n = nameFrom(fl.name); PERSONAL[n] = await read(fl); added.push("." + n + ".");
      }
      save(); render(); file.value = "";
      msg.textContent = (added.length ? "Added " + added.join(" ") + ". Use them in any message." : "")
        + (skipped.length ? " Skipped (over 2 MB): " + skipped.join(", ") + "." : "");
    };
    add.append(file, btn, msg);
    render();
    box.append(h, list, add);
    return box;
  }

  /* ---------- trigger ---------- */
  wantsConversion(text) {
    if (/(^|\s)\/(cz|shk|shake|rb|rainbow|wave|type|swing|bop|headbop|nudge|billboard|bill|bilr|bilu|bild|spin|jelly|drunk|scramble|ghost)(?=\s|$)/i.test(text)) return true;
    if (/[\[({<](rainbow|rb|wave|shake|shk|bounce|glow|pulse|glitch|headbop|bop|swing|spin|jelly|drunk|scramble|ghost|colou?r=[^\])}>]+)[\])}>]/i.test(text)) return true;
    if (new RegExp("[\\[({<](?:(?:" + TOK + ")" + SEP + ")+", "i").test(text)) return true; // (#f00/wave/text)
    if (/(^|[^\w:]):[^:\s<>][^:\n<>]*\s[^:\n<>]*[^:\s<>]:(?!\w)/.test(text)) return true; // :text with a space: (single words are emoji)
    for (const m of text.matchAll(/(^|[^\w.])\.([A-Za-z0-9_]{2,32})\.(?!\w)/g)) if (PERSONAL[m[2].toLowerCase()]) return true; // .myemoji.
    return false;
  }

  /* ---------- convert + upload ---------- */
  async convertAndUpload(channelId, content) {
    BdApi.UI.showToast("MyCustom: rendering…", { type: "info", timeout: 1200 });
    const style = this.readDiscordStyle();
    await document.fonts.ready;
    const parsed = parse(content);
    await loadEmojis(parsed);
    await Promise.all(Object.values(FONT_FACES).map(ff => ff.loaded.catch(() => {})));
    const lo = layout(parsed, style, this.settings);
    const blob = await makeWebp(lo, style);
    const file = new File([blob], "message.webp", { type: "image/webp" });
    if (this.addToUploads(channelId, file)) {
      BdApi.UI.showToast("MyCustom: ready. Press Enter to send.", { type: "success" });
    } else {
      throw new Error("Could not add the image to the upload tray");
    }
  }

  addToUploads(channelId, file) {
    try {
      const Uploader = BdApi.Webpack.getByKeys("promptToUpload");
      const ChannelStore = BdApi.Webpack.getStore ? BdApi.Webpack.getStore("ChannelStore") : BdApi.Webpack.getByKeys("getChannel", "hasChannel");
      if (Uploader && ChannelStore) { Uploader.promptToUpload([file], ChannelStore.getChannel(channelId), 0); return true; }
    } catch (e) { console.warn("[MyCustom] promptToUpload failed", e); }
    // Fallback: paste the file into the message box like Ctrl+V would.
    try {
      const box = document.querySelector('[role="textbox"][data-slate-editor="true"]');
      if (!box) return false;
      const dt = new DataTransfer(); dt.items.add(file);
      box.dispatchEvent(new ClipboardEvent("paste", { clipboardData: dt, bubbles: true, cancelable: true }));
      return true;
    } catch (e) { console.warn("[MyCustom] paste fallback failed", e); return false; }
  }

  readDiscordStyle() {
    const root = getComputedStyle(document.documentElement);
    const body = getComputedStyle(document.body);
    const v = (names, fb) => { for (const n of names) { const x = (body.getPropertyValue(n) || root.getPropertyValue(n)).trim(); if (x) return x; } return fb; };
    // Measure a real message, never a reply preview, embed or the small grey "replying to" line
    const isPreview = el => el.closest('[class*="repliedMessage"],[class*="repliedText"],[class*="replyBar"],[class*="embed"],[class*="threadMessageAccessory"]');
    const candidates = [...document.querySelectorAll('[id^="message-content-"],[class*="messageContent"]')]
      .filter(el => !isPreview(el) && !el.closest('[class*="markup"] [class*="markup"]') && el.offsetParent);
    const sample = candidates[candidates.length - 1] || null;
    const rootSize = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16; // Discord's chat font scaling sets this
    const cs = sample ? getComputedStyle(sample) : null;
    let fontSize = cs ? parseFloat(cs.fontSize) || rootSize : rootSize;
    if (fontSize < rootSize * 0.95) fontSize = rootSize; // a too-small sample means we hit a preview; trust the chat setting
    return {
      family: (cs && cs.fontFamily) || '"gg sans","Noto Sans","Helvetica Neue",Helvetica,Arial,sans-serif',
      mono: '"gg mono","Source Code Pro",Consolas,"Courier New",monospace',
      scale: fontSize / 16,
      text: v(["--text-default", "--text-normal"], "#dbdee1"),
      muted: v(["--text-muted"], "#949ba4"),
      quote: v(["--background-modifier-accent", "--border-strong"], "#4e5058"),
      codeBg: v(["--background-secondary", "--background-base-lower"], "#2b2d31"),
      codeBd: v(["--background-tertiary", "--border-subtle"], "#1e1f22"),
      light: document.documentElement.classList.contains("theme-light") || document.body.classList.contains("theme-light"),
    };
  }
};

/* =================== renderer (shared with the MyCustom web tool) =================== */
const FPS = 20;
const BLOCK = {
  p: { size: 16, lh: 22, w: 400 }, h1: { size: 24, lh: 30, w: 700, mt: 8, mb: 2 }, h2: { size: 20, lh: 26, w: 700, mt: 8, mb: 2 },
  h3: { size: 16, lh: 22, w: 700, mt: 6, mb: 2 }, sub: { size: 13, lh: 18, w: 400, muted: true }, code: { size: 14, lh: 18, w: 400, mono: true }
};
const FX_ALIAS = { rainbow: "rainbow", rb: "rainbow", wave: "wave", shake: "shake", shk: "shake", bounce: "bounce", glow: "glow", pulse: "pulse", glitch: "glitch", headbop: "headbop", bop: "headbop", swing: "swing", spin: "spin", jelly: "jelly", drunk: "drunk", scramble: "scramble", ghost: "ghost" };
const FLAG_ALIAS = { shk: "shake", shake: "shake", rb: "rainbow", rainbow: "rainbow", wave: "wave", type: "type", swing: "swing", bop: "headbop", headbop: "headbop", nudge: "nudge", billboard: "bill", bill: "bill", bilr: "bilr", bilu: "bilu", bild: "bild", spin: "spin", jelly: "jelly", drunk: "drunk", scramble: "scramble", ghost: "ghost", cz: null };
const SCRAMBLE = "ABCDEFGHJKLMNPQRSTUVWXYZ0123456789#%&@$*?!";
const HEX = "#[0-9a-f]{3,8}";
// One modifier inside (mod/mod/text). Gradients first so a plain #hex doesn't swallow them.
const TOK = "billboard|bill|bilr|bilu|bild|font[a-z]{1,4}|gradient\\((?:" + HEX + "[\\/,]?)+\\)|" + HEX + "(?:>" + HEX + ")+|(?:headbop|bop)(?:=\\d{2,3})?|rainbow|rb|wave|shake|shk|bounce|glow|pulse|glitch|swing|spin|jelly|drunk|scramble|ghost|" + HEX + "|colou?r=(?:" + HEX + "|[a-z]+)";
const DEFAULT_BPM = 75;
const SEP = "(?:\\/|(?<=\\)))"; // a "/" between modifiers; optional right after gradient(...)
let BBID = 0;
function hexRgb(h) {
  h = h.replace("#", "");
  if (h.length <= 4) h = [...h.slice(0, 3)].map(c => c + c).join(""); else h = h.slice(0, 6);
  return [0, 2, 4].map(i => parseInt(h.slice(i, i + 2), 16) || 0);
}

function parse(src) {
  const flags = new Set();
  src = src.replace(/(?<=^|[ \t])\/(cz|shk|shake|rb|rainbow|wave|type|swing|bop|headbop|nudge|billboard|bill|bilr|bilu|bild|spin|jelly|drunk|scramble|ghost)(?=\s|$)[ \t]?/gim, (m, f) => { const k = FLAG_ALIAS[f.toLowerCase()]; if (k) flags.add(k); return ""; });
  const used = new Set(flags);
  const lines = []; let inCode = false;
  for (let raw of src.replace(/\s+$/, "").split("\n")) {
    if (/^\s*```/.test(raw)) { inCode = !inCode; continue; }
    if (inCode) { lines.push({ type: "code", runs: [{ text: raw || " ", st: {} }] }); continue; }
    const L = { type: "p", quote: false, list: null }; let m;
    if ((m = raw.match(/^>\s(.*)$/)) || raw === ">") { L.quote = true; raw = m ? m[1] : ""; }
    if ((m = raw.match(/^(#{1,3})\s+(.*)$/))) { L.type = "h" + m[1].length; raw = m[2]; }
    else if ((m = raw.match(/^-#\s+(.*)$/))) { L.type = "sub"; raw = m[1]; }
    if ((m = raw.match(/^\s*[-*]\s+(.*)$/))) { L.list = "•"; raw = m[1]; }
    else if ((m = raw.match(/^\s*(\d{1,3})\.\s+(.*)$/))) { L.list = m[1] + "."; raw = m[2]; }
    L.runs = []; inline(raw, {}, L.runs, used); lines.push(L);
  }
  if (!lines.length) lines.push({ type: "p", runs: [] });
  // Emoji-only messages show as big "jumbo" emoji in Discord
  let emojiCount = 0, onlyEmoji = true;
  for (const L of lines) for (const r of L.runs) { if (r.emoji) emojiCount++; else if (r.text.trim()) onlyEmoji = false; }
  const jumbo = onlyEmoji && emojiCount > 0 && emojiCount <= 30 && lines.every(L => L.type === "p" && !L.quote && !L.list);
  if (flags.has("headbop") && !used.bpm) used.bpm = DEFAULT_BPM;
  return { lines, flags, used, jumbo };
}

let PERSONAL = {};
let FONTS = {};        // code -> { name, data (data URL) }
const FONT_FACES = {}; // code -> FontFace
// a, b, … z, aa, ab, … az, ba, … (like spreadsheet columns)
function fontCodeAt(n) { let s = ""; n++; while (n > 0) { n--; s = String.fromCharCode(97 + (n % 26)) + s; n = Math.floor(n / 26); } return s; }
function nextFontCode() { for (let i = 0; ; i++) { const c = fontCodeAt(i); if (!FONTS[c]) return c; } }
function fontFamilyName(code) { return "MyCustom font " + code; }
function dataUrlToBuffer(url) { const bin = atob(url.split(",")[1]); const u8 = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) u8[i] = bin.charCodeAt(i); return u8.buffer; }
async function registerFont(code) {
  unregisterFont(code);
  const ff = new FontFace(fontFamilyName(code), dataUrlToBuffer(FONTS[code].data));
  FONT_FACES[code] = ff;
  try { await ff.load(); document.fonts.add(ff); }
  catch (e) { delete FONT_FACES[code]; console.warn("[MyCustom] font failed to load", code, e); throw e; }
}
function unregisterFont(code) { const ff = FONT_FACES[code]; if (ff) { try { document.fonts.delete(ff); } catch { } delete FONT_FACES[code]; } }
const EMOJI_RE = /^(?:[\u{1F1E6}-\u{1F1FF}]{2}|[#*0-9]️?⃣|\p{Extended_Pictographic}(?:️|\p{Emoji_Modifier})*(?:‍\p{Extended_Pictographic}(?:️|\p{Emoji_Modifier})*)*)/u;

/* ---------- emoji images ---------- */
let emojiUrlFn;
function discordEmojiURL(u) {
  if (emojiUrlFn === undefined) {
    emojiUrlFn = null;
    try {
      const mod = BdApi.Webpack.getModule(m => {
        if (!m || typeof m.getURL !== "function") return false;
        try { const r = m.getURL("😀"); return typeof r === "string" && /\.svg/.test(r); } catch { return false; }
      });
      if (mod) emojiUrlFn = s => mod.getURL(s);
    } catch { }
  }
  try { return emojiUrlFn ? emojiUrlFn(u) : null; } catch { return null; }
}
function twemojiURL(u) {
  const s = u.includes("‍") ? u : u.replace(/️/g, "");
  return `https://cdn.jsdelivr.net/gh/jdecked/twemoji@15.1.0/assets/svg/${Array.from(s).map(c => c.codePointAt(0).toString(16)).join("-")}.svg`;
}
async function blobToImage(blob) {
  if (/svg/.test(blob.type)) {
    let txt = await blob.text();
    if (!/<svg[^>]*\swidth=/.test(txt)) txt = txt.replace(/<svg\b/, '<svg width="128" height="128"');
    blob = new Blob([txt], { type: "image/svg+xml" });
  }
  const img = new Image(); img.src = URL.createObjectURL(blob); await img.decode(); return img;
}
async function decodeAnimated(blob) {
  const dec = new ImageDecoder({ data: await blob.arrayBuffer(), type: blob.type || "image/gif" });
  await dec.tracks.ready;
  const n = dec.tracks.selectedTrack.frameCount; const frames = []; let t = 0;
  for (let i = 0; i < n; i++) {
    const { image } = await dec.decode({ frameIndex: i });
    const d = Math.max(20, (image.duration || 100000) / 1000);
    frames.push({ bmp: await createImageBitmap(image), start: t }); image.close(); t += d;
  }
  return { frames, total: t };
}
async function loadOne(e) {
  try {
    if (e.personal) {
      const [head, b64] = PERSONAL[e.personal].split(",");
      const type = (head.match(/data:([^;]+)/) || [])[1] || "image/png";
      const bin = atob(b64); const u8 = new Uint8Array(bin.length); for (let j = 0; j < bin.length; j++) u8[j] = bin.charCodeAt(j);
      const blob = new Blob([u8], { type });
      if (/gif|webp/.test(type) && window.ImageDecoder) { const a = await decodeAnimated(blob); return a.frames.length > 1 ? a : { img: a.frames[0].bmp }; }
      return { img: await blobToImage(blob) };
    }
    if (e.custom) {
      const res = await fetch(`https://cdn.discordapp.com/emojis/${e.custom}.${e.animated ? "gif" : "png"}?size=96`);
      const blob = await res.blob();
      if (e.animated && window.ImageDecoder) { const a = await decodeAnimated(blob); return a.frames.length > 1 ? a : { img: a.frames[0].bmp }; }
      return { img: await blobToImage(blob) };
    }
    for (const url of [discordEmojiURL(e.uni), twemojiURL(e.uni)]) {
      if (!url) continue;
      try { const res = await fetch(url); if (res.ok) return { img: await blobToImage(await res.blob()) }; } catch { }
    }
  } catch (err) { console.warn("[MyCustom] emoji failed to load", e, err); }
  return {};
}
async function loadEmojis(P) {
  const cache = new Map(), jobs = [];
  for (const L of P.lines) for (const r of L.runs) if (r.emoji) {
    const key = r.emoji.personal ? "p:" + r.emoji.personal : (r.emoji.custom || r.emoji.uni);
    if (!cache.has(key)) cache.set(key, loadOne(r.emoji));
    jobs.push(cache.get(key).then(v => Object.assign(r.emoji, v)));
  }
  await Promise.all(jobs);
  let longest = 0;
  for (const L of P.lines) for (const r of L.runs) if (r.emoji && r.emoji.total) longest = Math.max(longest, r.emoji.total);
  P.emojiLoopMs = longest;
  if (longest) P.used.add("anim");
}

function inline(str, st, out, used) {
  let i = 0, buf = "";
  const flush = () => { if (buf) { out.push({ text: buf, st }); buf = ""; } };
  const isW = c => !!c && /[\p{L}\p{N}_]/u.test(c);
  while (i < str.length) {
    const rest = str.slice(i), c = str[i];
    if (c === "\\" && i + 1 < str.length && /[*_~`|:\[\](){}<>\\#-]/.test(str[i + 1])) { buf += str[i + 1]; i += 2; continue; }
    if (c === "<") { // Discord custom emoji <:name:id> / <a:name:id>
      const m = rest.match(/^<(a?):(\w+):(\d+)>/);
      if (m) { flush(); out.push({ text: "", st, emoji: { custom: m[3], animated: !!m[1], name: m[2] } }); if (m[1]) used.add("anim"); i += m[0].length; continue; }
    }
    if (c === "`") { const j = str.indexOf("`", i + 1); if (j > i + 1) { flush(); out.push({ text: str.slice(i + 1, j), st: { ...st, code: true } }); i = j + 1; continue; } }
    // Short form, stackable, content last: (wave/text)  (#ff0000/text)  (#ff0000/wave/text)
    const sm = "[({<".includes(c) && rest.match(new RegExp("^([\\[({<])((?:(?:" + TOK + ")" + SEP + ")+)", "i"));
    if (sm) {
      const open = sm[1], close = { "[": "]", "(": ")", "{": "}", "<": ">" }[open];
      let depth = 1, j = i + sm[0].length;
      for (; j < str.length; j++) { if (str[j] === "\\") { j++; continue; } if (str[j] === open) depth++; else if (str[j] === close && --depth === 0) break; }
      if (j < str.length) {
        const ns = { ...st };
        for (const mm of sm[2].matchAll(new RegExp("(" + TOK + ")" + SEP, "gi"))) {
          const tok = mm[1], t = tok.toLowerCase();
          const hexes = t.match(/#[0-9a-f]{3,8}/g) || [];
          if (t.startsWith("gradient") || (t[0] === "#" && t.includes(">"))) { ns.grad = hexes.map(hexRgb); if (ns.grad.length === 1) { ns.color = hexes[0]; delete ns.grad; } else used.add("gradient"); }
          else if (/^bil/.test(t)) {
            const dir = t === "billboard" || t === "bill" ? "l" : t === "bilr" ? "r" : t === "bilu" ? "u" : "d";
            ns.bb = { ...(ns.bb || {}), [dir]: true }; ns.bbId = ns.bbId || ++BBID; used.add("billboard");
          }
          else if (/^font[a-z]+$/.test(t)) { const c = t.slice(4); if (FONTS[c]) ns.font = c; }
          else if (t[0] === "#") ns.color = t;
          else if (t.startsWith("col")) ns.color = tok.split("=")[1];
          else {
            const name = t.split("=")[0], k = FX_ALIAS[name];
            ns.fx = new Set([...(ns.fx || []), k]); used.add(k);
            if (k === "headbop") { const b = +(t.split("=")[1] || DEFAULT_BPM); ns.bpm = Math.min(300, Math.max(30, b)); if (!used.bpm) used.bpm = ns.bpm; }
          }
        }
        flush(); inline(str.slice(i + sm[0].length, j), ns, out, used); i = j + 1; continue;
      }
    }
    if ("[({<".includes(c)) {
      let m = rest.match(/^[\[({<](rainbow|rb|wave|shake|shk|bounce|glow|pulse|glitch|headbop|bop|swing|spin|jelly|drunk|scramble|ghost)[\])}>]/i), close, ns;
      if (m) { const k = FX_ALIAS[m[1].toLowerCase()]; if (k === "headbop" && !used.bpm) used.bpm = DEFAULT_BPM; close = new RegExp("[\\[({<]\\/(" + Object.keys(FX_ALIAS).filter(a => FX_ALIAS[a] === k).join("|") + ")[\\])}>]", "i"); ns = { ...st, fx: new Set([...(st.fx || []), k]) }; used.add(k); }
      else if ((m = rest.match(/^[\[({<]colou?r=(#[0-9a-f]{3,8}|[a-z]+)[\])}>]/i))) { close = /[\[({<]\/colou?r[\])}>]/i; ns = { ...st, color: m[1] }; }
      if (m) { const after = str.slice(i + m[0].length); const cm = after.match(close); if (cm) { flush(); inline(after.slice(0, cm.index), ns, out, used); i += m[0].length + cm.index + cm[0].length; continue; } }
    }
    let done = false;
    for (const [mk, key] of [["**", "b"], ["__", "u"], ["~~", "s"], ["*", "i"], ["_", "i"]]) {
      if (!rest.startsWith(mk)) continue;
      if (mk === "_" && isW(str[i - 1])) break;
      const j = str.indexOf(mk, i + mk.length);
      if (j > i + mk.length && !/^\s/.test(str[i + mk.length]) && !(mk === "_" && isW(str[j + 1]))) { flush(); inline(str.slice(i + mk.length, j), { ...st, [key]: true }, out, used); i = j + mk.length; done = true; }
      break;
    }
    if (done) continue;
    if (c === ":" && !isW(str[i - 1])) {
      const m = rest.match(/^:([^:\s](?:[^:\n]*?[^:\s])?):/);
      if (m && /\s/.test(m[1]) && !isW(str[i + m[0].length])) { flush(); inline(m[1], { ...st, fx: new Set([...(st.fx || []), "rainbow"]) }, out, used); used.add("rainbow"); i += m[0].length; continue; }
    }
    if (c === "." && !isW(str[i - 1]) && str[i - 1] !== ".") {
      const m = rest.match(/^\.([A-Za-z0-9_]{2,32})\.(?!\w)/);
      if (m && PERSONAL[m[1].toLowerCase()]) { flush(); out.push({ text: "", st, emoji: { personal: m[1].toLowerCase(), name: m[1] } }); i += m[0].length; continue; }
    }
    const em = rest.match(EMOJI_RE);
    if (em && !/^[©®™‼⁉](?!️)/.test(em[0])) { flush(); out.push({ text: "", st, emoji: { uni: em[0] } }); i += em[0].length; continue; }
    buf += c; i++;
  }
  flush();
}

function layout(P, S, cfg) {
  const k = S.scale, maxW = cfg.maxWidth;
  const mctx = document.createElement("canvas").getContext("2d");
  const fontFor = (B, st) => (st.code || B.mono)
    ? `400 ${Math.round((B.mono ? B.size : B.size * 0.85) * k)}px ${S.mono}`
    : `${st.i ? "italic " : ""}${st.b ? 700 : B.w} ${Math.round(B.size * k)}px ${st.font && FONT_FACES[st.font] ? `"${fontFamilyName(st.font)}",` : ""}${S.family}`;
  const G = [], D = []; let y = 0, gi = 0, row = 0, maxX = 0, codeStart = 0;
  P.lines.forEach((L, li) => {
    const B = BLOCK[L.type], lh = B.lh * k;
    const prevType = li ? P.lines[li - 1].type : null;
    if (L.type === "code" && prevType !== "code") { codeStart = y; y += 8; }
    if (li && B.mt) y += B.mt * k;
    const indent = (L.quote ? 16 : 0) + (L.list ? 24 * k : 0) + (L.type === "code" ? 8 : 0);
    const lineTop = y; const rows = []; let cur = []; let x = indent;
    const size = mono => Math.round((mono ? (B.mono ? B.size : B.size * 0.85) : B.size) * k);
    const push = (ch, cx, adv, font, st, mono) => cur.push({ ch, x: cx, adv, font, st, size: size(mono), muted: !!B.muted, idx: gi++, list: false });
    const newRow = () => { rows.push(cur); cur = []; x = indent; };
    for (const r of L.runs) {
      if (r.emoji) {
        const es = Math.round((P.jumbo ? 48 : B.size * 1.375) * k);
        const ml = B.size * k * 0.1, mr = B.size * k * 0.05;
        if (x + ml + es > maxW && x > indent) newRow();
        cur.push({ emoji: r.emoji, x: x + ml, adv: es, eSize: es, st: r.st, size: es, muted: false, idx: gi++, list: false, font: fontFor(B, {}) });
        x += ml + es + mr; continue;
      }
      const font = fontFor(B, r.st); mctx.font = font;
      const mono = r.st.code || B.mono;
      if (r.st.code) x += 3;
      for (const part of r.text.split(/(\s+)/)) {
        if (!part) continue;
        const sp = /^\s+$/.test(part);
        if (sp && cur.length === 0 && rows.length) continue;
        const w = mctx.measureText(part).width;
        if (!sp && x + w > maxW && x > indent) newRow();
        const chars = Array.from(part); let acc = "", prevW = 0;
        for (const ch of chars) {
          const nw = mctx.measureText(acc + ch).width;
          if (!sp && x + nw > maxW && x + prevW > indent && w > maxW - indent) {
            x += prevW; newRow(); acc = ""; prevW = 0;
            const nw2 = mctx.measureText(ch).width; push(ch, x, nw2, font, r.st, mono); acc = ch; prevW = nw2; continue;
          }
          push(ch, x + prevW, nw - prevW, font, r.st, mono); acc += ch; prevW = nw;
        }
        x += prevW;
      }
      if (r.st.code) x += 3;
    }
    rows.push(cur);
    mctx.font = fontFor(B, {});
    const mm = mctx.measureText("Hg");
    const asc = mm.fontBoundingBoxAscent ?? B.size * k * 0.92, desc = mm.fontBoundingBoxDescent ?? B.size * k * 0.26;
    rows.forEach((rg, ri) => {
      const rowH = Math.max(lh, ...rg.map(g => g.eSize || 0));
      const base = y + rowH - lh + (lh - (asc + desc)) / 2 + asc;
      for (const g of rg) { if (g.emoji) g.top = y + rowH - g.eSize; g.rowTop = y; g.rowH = rowH; }
      if (ri === 0 && L.list) {
        const lw = mctx.measureText(L.list).width;
        const lx = (L.quote ? 16 : 0) + (L.list === "•" ? 8 * k : 20 * k - lw);
        G.push({ ch: L.list, x: lx, adv: lw, font: fontFor(B, {}), st: {}, size: B.size * k, muted: false, idx: -1, base, row, list: true });
      }
      let cs = null;
      for (const g of rg) {
        g.base = base; g.row = row; G.push(g); maxX = Math.max(maxX, g.x + g.adv);
        if (g.st.code && !B.mono) { if (cs && Math.abs(cs.x2 - g.x) < 0.5) cs.x2 = g.x + g.adv; else { cs = { t: "icode", x1: g.x, x2: g.x + g.adv, y: y + 1, h: lh - 2 }; D.push(cs); } }
        else cs = null;
      }
      y += rowH; row++;
    });
    if (L.quote) {
      const last = D[D.length - 1];
      if (last && last.t === "bar" && Math.abs(last.y + last.h - lineTop) < 0.5) last.h = y - last.y; else D.push({ t: "bar", y: lineTop, h: y - lineTop });
    }
    if (B.mb) y += B.mb * k;
    if (L.type === "code" && (li === P.lines.length - 1 || P.lines[li + 1].type !== "code")) { y += 8; D.push({ t: "cblock", y: codeStart, h: y - codeStart, w: maxW }); maxX = Math.max(maxX, maxW); }
  });
  D.forEach(d => { if (d.t === "icode") { d.x1 -= 3; d.x2 += 3; maxX = Math.max(maxX, d.x2); } });
  const fx = P.used;
  const swings = fx.has("swing");
  const moves = fx.has("shake") || fx.has("glitch") || fx.has("glow") || swings || ["spin", "jelly", "drunk", "ghost", "nudge"].some(k => fx.has(k));
  const vert = moves || fx.has("wave") || fx.has("bounce");
  const SW_PAD = 9;
  const pad = { l: fx.has("nudge") ? 4 : moves ? 3 : 0, r: moves ? 6 : 2, t: swings ? SW_PAD : vert ? 5 : 0, b: swings ? SW_PAD : vert ? 5 : 1 };
  // Swing: rotate as far as fits inside the padding, at least 2°, at most 15°
  const swingAmp = (w, h) => { let a = 0.26; while (a > 0.035 && (w * Math.sin(a) + h * Math.cos(a)) / 2 - h / 2 > SW_PAD - 1) a -= 0.005; return Math.max(0.035, a); };
  let gsw = null;
  if (P.flags.has("swing")) gsw = { cx: maxX / 2, cy: y / 2, A: swingAmp(maxX, y) };
  else if (swings) {
    const groups = new Map();
    for (const g of G) {
      if (!g.st.fx || !g.st.fx.has("swing")) continue;
      let byRow = groups.get(g.st); if (!byRow) groups.set(g.st, byRow = new Map());
      let gr = byRow.get(g.row); if (!gr) byRow.set(g.row, gr = { x1: g.x, x2: g.x + g.adv, y1: g.rowTop, y2: g.rowTop + g.rowH });
      gr.x1 = Math.min(gr.x1, g.x); gr.x2 = Math.max(gr.x2, g.x + g.adv); g.sw = gr;
    }
    for (const byRow of groups.values()) for (const gr of byRow.values()) { gr.cx = (gr.x1 + gr.x2) / 2; gr.cy = (gr.y1 + gr.y2) / 2; gr.A = swingAmp(gr.x2 - gr.x1, gr.y2 - gr.y1); }
  }
  // Loop length: whole beats for headbop, emoji length for animated emojis alone, else the setting
  let loopSec = (fx.size === 1 && fx.has("anim") && P.emojiLoopMs) ? P.emojiLoopMs / 1000 : cfg.loopSeconds;
  let beats = 1;
  let loopCount = 0;
  const bb = ["bill", "bilr", "bilu", "bild"].filter(k => P.flags.has(k));
  if (bb.length) {
    const Wp = Math.ceil(maxX) + 48, Hp = Math.ceil(y) + 10;
    const horiz = P.flags.has("bill") || P.flags.has("bilr"), vert2 = P.flags.has("bilu") || P.flags.has("bild");
    loopSec = Math.min(10, Math.max(cfg.loopSeconds, horiz ? Wp / 70 : 0, vert2 ? Hp / 25 : 0));
  }
  if (fx.has("nudge") && [...fx].every(k => k === "nudge")) { loopSec = 0.6; loopCount = 1; } // nudge alone: play once, then stay still
  if (fx.has("headbop")) { const beat = 60 / (fx.bpm || DEFAULT_BPM); beats = Math.max(1, Math.round(cfg.loopSeconds / beat)); loopSec = beats * beat; }
  // Inline billboards: each span (per row) becomes its own little scrolling window
  if (fx.has("billboard")) {
    const groups = new Map();
    for (const g of G) {
      if (!g.st.bb || g.list) continue;
      const key = g.st.bbId + ":" + g.row;
      let b = groups.get(key);
      if (!b) groups.set(key, b = { x1: g.x, x2: g.x + g.adv, y1: g.rowTop, y2: g.rowTop + g.rowH, dir: g.st.bb });
      b.x1 = Math.min(b.x1, g.x); b.x2 = Math.max(b.x2, g.x + g.adv); g.bbg = b;
    }
    for (const b of groups.values()) {
      const h = b.dir.l || b.dir.r, v = b.dir.u || b.dir.d;
      if (h) loopSec = Math.max(loopSec, Math.min(10, (b.x2 - b.x1 + 24) / 70));
      if (v) loopSec = Math.max(loopSec, Math.min(10, (b.y2 - b.y1 + 4) / 25));
    }
  }
  return {
    G, D, pad, flags: P.flags, gsw, beats, loopCount,
    bb: bb.length ? { l: P.flags.has("bill"), r: P.flags.has("bilr"), u: P.flags.has("bilu"), d: P.flags.has("bild") } : null, bpm: fx.bpm || DEFAULT_BPM,
    W: Math.max(1, Math.ceil(maxX) + pad.l + pad.r), H: Math.max(1, Math.ceil(y) + pad.t + pad.b),
    nGlyph: G.filter(g => !g.list).length,
    nF: fx.size === 0 ? 1 : Math.max(2, Math.round(loopSec * FPS)),
  };
}

const rnd = (a, b) => { const s = Math.sin(a * 12.9898 + b * 78.233) * 43758.5453; return s - Math.floor(s) - .5; };
function rr(ctx, x, y, w, h, r) { ctx.beginPath(); if (ctx.roundRect) ctx.roundRect(x, y, w, h, r); else ctx.rect(x, y, w, h); ctx.fill(); }

function drawFrame(ctx, Lo, S, f, inner) {
  const t = f / Lo.nF, TAU = Math.PI * 2;
  if (Lo.bb && !inner) {
    const off = Lo._off || (Lo._off = document.createElement("canvas"));
    off.width = Lo.W; off.height = Lo.H;
    drawFrame(off.getContext("2d"), Lo, S, f, true);
    const b = Lo.bb, Wp = Lo.W + 48, Hp = Lo.H + 10;
    // one direction = continuous scroll; both opposite directions = slide back and forth
    const axis = (neg, pos, period) => neg && pos ? Math.sin(TAU * t) * period / 2 : neg ? -t * period : pos ? t * period : 0;
    const ox = axis(b.l, b.r, Wp), oy = axis(b.u, b.d, Hp);
    ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, Lo.W, Lo.H);
    const bx = ((ox % Wp) + Wp) % Wp, by = ((oy % Hp) + Hp) % Hp;
    for (const tx of [bx - Wp, bx]) for (const ty of [by - Hp, by]) ctx.drawImage(off, Math.round(tx), Math.round(ty));
    return;
  }
  ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.clearRect(0, 0, Lo.W, Lo.H);
  ctx.translate(Lo.pad.l, Lo.pad.t);
  if (Lo.flags.has("shake")) ctx.translate(Math.round(rnd(f, 1) * 4), Math.round(rnd(f, 2) * 3));
  if (Lo.flags.has("nudge")) { const p = f / FPS / 0.5; if (p < 1) { const amp = Math.pow(1 - p, 1.5); ctx.translate(Math.round((f % 2 ? 1 : -1) * 4 * amp), Math.round(rnd(f, 13) * 3 * amp)); } }
  if (Lo.gsw) { const a = Lo.gsw.A * Math.sin(TAU * t); ctx.translate(Lo.gsw.cx, Lo.gsw.cy); ctx.rotate(a); ctx.translate(-Lo.gsw.cx, -Lo.gsw.cy); }
  for (const d of Lo.D) {
    if (d.t === "bar") { ctx.fillStyle = S.quote; rr(ctx, 0, d.y, 4, d.h, 2); }
    if (d.t === "cblock") { ctx.fillStyle = S.codeBd; rr(ctx, 0, d.y, d.w, d.h, 4); ctx.fillStyle = S.codeBg; rr(ctx, 1, d.y + 1, d.w - 2, d.h - 2, 3); }
    if (d.t === "icode") { ctx.fillStyle = S.codeBd; rr(ctx, d.x1, d.y, d.x2 - d.x1, d.h, 4); ctx.fillStyle = S.codeBg; rr(ctx, d.x1 + 1, d.y + 1, d.x2 - d.x1 - 2, d.h - 2, 3); }
  }
  const visible = Lo.flags.has("type") ? Math.ceil(Math.min(1, t / 0.7) * Lo.nGlyph) : Infinity;
  const glitchOn = rnd(f, 7) + .5 < 0.28;
  ctx.textBaseline = "alphabetic";
  const drawGlyph = g => {
    if (!g.list && g.idx >= visible) return;
    if (g.list && visible === 0) return;
    const fx = g.st.fx || new Set();
    const has = n => fx.has(n) || (Lo.flags.has(n) && n !== "shake" && n !== "swing");
    let color = g.st.color || (g.muted ? S.muted : S.text);
    let dx = 0, dy = 0, alpha = 1, blur = 0;
    if (g.st.grad && !g.list) {
      const cs = g.st.grad, n = cs.length, pos = (((g.idx * 0.06 - t) % 1) + 1) % 1 * n;
      const i0 = Math.floor(pos) % n, fr = pos - Math.floor(pos), e = fr * fr * (3 - 2 * fr);
      const a = cs[i0], b = cs[(i0 + 1) % n];
      color = `rgb(${Math.round(a[0] + (b[0] - a[0]) * e)},${Math.round(a[1] + (b[1] - a[1]) * e)},${Math.round(a[2] + (b[2] - a[2]) * e)})`;
    }
    if (has("rainbow") && !g.list) color = `hsl(${((g.idx * 14 - t * 360) % 360 + 360) % 360},88%,${S.light ? 48 : 66}%)`;
    if (has("wave")) dy += -Math.sin(TAU * (t + g.idx * 0.07)) * 3;
    if (has("bounce")) dy += -Math.abs(Math.sin(Math.PI * (t * 2 + g.idx * 0.08))) * 4;
    if (fx.has("shake")) { dx += rnd(f * 31 + g.idx, 3) * 3; dy += rnd(f * 17 + g.idx, 5) * 3; }
    if (has("pulse")) alpha = 0.6 + 0.4 * Math.cos(TAU * t);
    if (has("glow")) blur = 5 + 4 * Math.sin(TAU * t);
    const gl = has("glitch") && glitchOn;
    if (gl) dx += Math.round(rnd(f, g.row) * 6);
    let rot = 0, jx = 1, jy = 1, ch = g.ch, ghostOff = 0;
    if (has("spin") && !g.list) { const ph = (((t - g.idx * 0.05) % 1) + 1) % 1; if (ph < 0.4) { const q = ph / 0.4; rot = TAU * (q < 0.5 ? 4 * q * q * q : 1 - Math.pow(-2 * q + 2, 3) / 2); } }
    if (has("drunk")) { rot += 0.2 * Math.sin(TAU * (t + g.idx * 0.13)); dy += 2 * Math.sin(TAU * (t * 2 + g.idx * 0.21)); dx += 1.2 * Math.sin(TAU * t + g.idx); }
    if (has("jelly")) { jx = 1 + 0.2 * Math.sin(TAU * (t * 2 + g.idx * 0.12)); jy = 1 / jx; }
    if (has("ghost")) { ghostOff = -2.5 * Math.sin(TAU * (t + g.idx * 0.05)); dy += ghostOff; }
    if (has("scramble") && !g.emoji && !g.list && g.ch && g.ch.trim()) {
      const reveal = 0.1 + 0.6 * (g.idx / (Lo.nGlyph || 1));
      if (t < reveal) { const pool = g.ch === g.ch.toLowerCase() && g.ch !== g.ch.toUpperCase() ? SCRAMBLE.toLowerCase() : SCRAMBLE; ch = pool[Math.floor((rnd(f, g.idx * 7) + 0.5) * pool.length) % pool.length]; }
    }
    const X = g.x + dx, Y = g.base + dy;
    // Headbop: squash to 50% on every beat, then ease back up (anchored at the baseline)
    let sy = 1;
    if (has("headbop")) { const nb = g.st.bpm ? Math.max(1, Math.round(Lo.beats * g.st.bpm / Lo.bpm)) : Lo.beats; const p = (t * nb) % 1; sy = 0.5 + 0.5 * (1 - Math.pow(1 - p, 3)); }
    const swA = g.sw ? g.sw.A * Math.sin(TAU * t) : 0;
    const xf = sy !== 1 || swA !== 0 || rot !== 0 || jx !== 1;
    if (xf) {
      ctx.save();
      if (swA) { ctx.translate(g.sw.cx, g.sw.cy); ctx.rotate(swA); ctx.translate(-g.sw.cx, -g.sw.cy); }
      if (sy !== 1) { const ay = g.emoji ? g.top + dy + g.eSize : Y; ctx.translate(0, ay); ctx.scale(1, sy); ctx.translate(0, -ay); }
      if (rot) { const cx = X + g.adv / 2, cy = g.emoji ? g.top + dy + g.eSize / 2 : Y - g.size * 0.35; ctx.translate(cx, cy); ctx.rotate(rot); ctx.translate(-cx, -cy); }
      if (jx !== 1) { const cx = X + g.adv / 2, ay = g.emoji ? g.top + dy + g.eSize : Y; ctx.translate(cx, ay); ctx.scale(jx, jy); ctx.translate(-cx, -ay); }
    }
    ctx.font = g.font; ctx.globalAlpha = alpha;
    if (g.emoji) {
      const e = g.emoji; let src = e.img;
      if (e.frames) { const ms = (f * 1000 / FPS) % e.total; src = e.frames[0].bmp; for (const fr of e.frames) if (fr.start <= ms) src = fr.bmp; }
      ctx.shadowColor = S.text; ctx.shadowBlur = blur;
      if (src) ctx.drawImage(src, X, g.top + dy, g.eSize, g.eSize);
      else { ctx.fillStyle = color; ctx.fillText(e.uni || ":" + e.name + ":", X, Y); }
      ctx.shadowBlur = 0; if (xf) ctx.restore(); return;
    }
    if (has("ghost")) {
      ctx.fillStyle = color;
      for (let k = 2; k >= 1; k--) { const off = -2.5 * Math.sin(TAU * (t - k * 0.07 + g.idx * 0.05)); ctx.globalAlpha = alpha * 0.18 * (3 - k); ctx.fillText(ch, X - k * 1.5, Y - ghostOff + off); }
      ctx.globalAlpha = alpha;
    }
    if (gl) { ctx.shadowBlur = 0; ctx.globalAlpha = alpha * 0.8; ctx.fillStyle = "#ff2d55"; ctx.fillText(ch, X - 1.5, Y); ctx.fillStyle = "#00e5ff"; ctx.fillText(ch, X + 1.5, Y); ctx.globalAlpha = alpha; }
    ctx.shadowColor = color; ctx.shadowBlur = blur; ctx.fillStyle = color;
    if (ch !== g.ch) ctx.fillText(ch, X, Y, Math.max(1, g.adv)); else ctx.fillText(ch, X, Y);
    ctx.shadowBlur = 0;
    const th = Math.max(1, Math.round(g.size / 16));
    if (g.st.u) ctx.fillRect(X, Math.round(Y + g.size * 0.14), g.adv, th);
    if (g.st.s) ctx.fillRect(X, Math.round(Y - g.size * 0.3), g.adv, th);
    if (xf) ctx.restore();
    };
  for (const g of Lo.G) {
    if (!g.bbg) { drawGlyph(g); continue; }
    const b = g.bbg, d = b.dir, h = d.l || d.r, v = d.u || d.d;
    const Wp = b.x2 - b.x1 + 24, Hp = b.y2 - b.y1 + 4;
    const axis = (neg, pos, period) => neg && pos ? Math.sin(TAU * t) * period / 2 : neg ? -t * period : pos ? t * period : 0;
    const ox = ((axis(d.l, d.r, Wp) % Wp) + Wp) % Wp, oy = ((axis(d.u, d.d, Hp) % Hp) + Hp) % Hp;
    ctx.save();
    ctx.beginPath(); ctx.rect(b.x1 - 1, v ? b.y1 : b.y1 - 6, b.x2 - b.x1 + 2, (b.y2 - b.y1) + (v ? 0 : 12)); ctx.clip();
    for (const tx of h ? [ox - Wp, ox] : [0]) for (const ty of v ? [oy - Hp, oy] : [0]) {
      ctx.save(); ctx.translate(Math.round(tx), Math.round(ty)); drawGlyph(g); ctx.restore();
    }
    ctx.restore();
  }
  ctx.globalAlpha = 1; ctx.shadowBlur = 0;
}

/* ---------- animated WebP muxer ---------- */
const enc = new TextEncoder();
function chunk(id, data) { const pad = data.length & 1; const out = new Uint8Array(8 + data.length + pad); out.set(enc.encode(id), 0); new DataView(out.buffer).setUint32(4, data.length, true); out.set(data, 8); return out; }
function u24(a, o, v) { a[o] = v & 255; a[o + 1] = (v >> 8) & 255; a[o + 2] = (v >> 16) & 255; }
function concat(parts) { const n = parts.reduce((a, p) => a + p.length, 0); const o = new Uint8Array(n); let k = 0; for (const p of parts) { o.set(p, k); k += p.length; } return o; }
function frameChunks(buf) {
  const u = new Uint8Array(buf), dv = new DataView(buf), dec = new TextDecoder();
  if (dec.decode(u.slice(0, 4)) !== "RIFF" || dec.decode(u.slice(8, 12)) !== "WEBP") throw new Error("Canvas did not produce WebP");
  const keep = []; let off = 12;
  while (off + 8 <= u.length) {
    const id = dec.decode(u.slice(off, off + 4)), size = dv.getUint32(off + 4, true);
    if (id === "ALPH" || id === "VP8 " || id === "VP8L") keep.push(chunk(id, u.slice(off + 8, off + 8 + size)));
    off += 8 + size + (size & 1);
  }
  return concat(keep);
}
async function makeWebp(Lo, S) {
  const c = document.createElement("canvas"); c.width = Lo.W; c.height = Lo.H; const x = c.getContext("2d");
  const toBlob = () => new Promise(r => c.toBlob(r, "image/webp", 1));
  if (Lo.nF === 1) { drawFrame(x, Lo, S, 0); return await toBlob(); }
  const dur = Math.round(1000 / FPS), frames = [];
  for (let f = 0; f < Lo.nF; f++) {
    drawFrame(x, Lo, S, f);
    const data = frameChunks(await (await toBlob()).arrayBuffer());
    const hdr = new Uint8Array(16); u24(hdr, 6, Lo.W - 1); u24(hdr, 9, Lo.H - 1); u24(hdr, 12, dur); hdr[15] = 0x02;
    frames.push(chunk("ANMF", concat([hdr, data])));
  }
  const vp8x = new Uint8Array(10); vp8x[0] = 0x12; u24(vp8x, 4, Lo.W - 1); u24(vp8x, 7, Lo.H - 1);
  const body = concat([enc.encode("WEBP"), chunk("VP8X", vp8x), chunk("ANIM", new Uint8Array([0, 0, 0, 0, (Lo.loopCount || 0) & 255, ((Lo.loopCount || 0) >> 8) & 255])), ...frames]);
  const head = new Uint8Array(8); head.set(enc.encode("RIFF")); new DataView(head.buffer).setUint32(4, body.length, true);
  return new Blob([head, body], { type: "image/webp" });
}
